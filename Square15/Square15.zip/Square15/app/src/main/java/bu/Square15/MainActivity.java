package bu.Square15;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.app.Activity;


public class MainActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) { //start main title page
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button play = (Button) findViewById(R.id.PlayButton);
        play.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Puzzle.class); //if you press begin, you will go to the puzzle
                startActivity(intent);
            }
        });

    }
}