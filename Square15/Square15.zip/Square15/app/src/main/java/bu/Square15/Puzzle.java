package bu.Square15;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;

import android.app.Activity;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Chronometer;
import android.widget.GridLayout;
import android.widget.Button;
import android.widget.TextView;

import static android.widget.GridLayout.*;

@SuppressWarnings("deprecation")
public class Puzzle extends Activity {
   
	private TextView moveCounter;
 	private TextView command;
    private Chronometer timer;
 	private Button[] buttons;
    private Boolean inval =false;
   	private static final Integer[] end_state = new Integer[] {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15}; //this is the arrangement needed to win the game
   	
	private ArrayList<Integer> myList = new ArrayList<Integer>(); //this is the arrangement of the buttons showing on the screen
    @Override
    public void onCreate(Bundle savedInstanceState) { //this is the game creation and loop that waits for a winner
        super.onCreate(savedInstanceState);
        setContentView(R.layout.puzzle);
        buttons=findButtons();


        for(int i=0;i<16;i++)
        {
            this.myList.add(i); //fill the array with the buttons
        }
        Collections.shuffle(this.myList);
        
        fill_grid(); //map buttons
       
        
       moveCounter = (TextView) findViewById(R.id.moveCounter); //count number of moves
	   command = (TextView) findViewById(R.id.command); //display if your command is valid
		
		for (int i = 1; i < 16; i++) {
			buttons[i].setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					slide((Button) v);
				}
			}); //slide button if touched and allowed to move
		}
		
		
		moveCounter.setText("0"); //start moves at 0
		command.setText(R.string.command); //start initial command check

        timer = (Chronometer) findViewById(R.id.timer);
        timer.setBase(SystemClock.elapsedRealtime());
        timer.start();
    
}
    public Button[] findButtons() {
		Button[] buttons = new Button[16]; //identify each button and put in the button array, check for input
		
		buttons[0] = (Button) findViewById(R.id.Button00);
		buttons[1] = (Button) findViewById(R.id.Button01);
		buttons[2] = (Button) findViewById(R.id.Button02);
		buttons[3] = (Button) findViewById(R.id.Button03);
		buttons[4] = (Button) findViewById(R.id.Button04);
		buttons[5] = (Button) findViewById(R.id.Button05);
		buttons[6] = (Button) findViewById(R.id.Button06);
		buttons[7] = (Button) findViewById(R.id.Button07);
		buttons[8] = (Button) findViewById(R.id.Button08);
		buttons[9] = (Button) findViewById(R.id.Button09);
		buttons[10] = (Button) findViewById(R.id.Button10);
		buttons[11] = (Button) findViewById(R.id.Button11);
		buttons[12] = (Button) findViewById(R.id.Button12);
		buttons[13] = (Button) findViewById(R.id.Button13);
		buttons[14] = (Button) findViewById(R.id.Button14);
		buttons[15] = (Button) findViewById(R.id.Button15);

		return buttons;
	}

    public void scrambleClicked(View v){ //scramble the buttons when the scramble button is touched
        if(v.getId() == R.id.scramble) {

            Collections.shuffle(this.myList);
            timer.setBase(SystemClock.elapsedRealtime());
            timer.start();

            fill_grid();

            moveCounter.setText("0"); //reset move counter
            command.setText(R.string.command); //reset command output
        }
    }


    public int find_position(int element) //finds the current position by index of the given button
    {
        int i=0;
        for(i=0;i<16;i++)
        {
            if(myList.get(i)==element)
            {
                break;
            }
        }
        return i;
    }

    public void fill_grid() //draws the grid with buttons arranged in the current order
    {

        for(int i=0;i<16;i++)
        {
            int text= myList.get(i);
            GridLayout.LayoutParams params; //get specs of the button
            switch(i)
            {case(0):

                Spec rowSpec; //make spec for row number
                Spec columnSpec; //make spec for column number
                rowSpec= spec(0); //set row number
                columnSpec= spec(0); //set column number
                params= new GridLayout.LayoutParams(rowSpec, columnSpec); //change the param location to the location of the array indice the button occupies
                buttons[text].setLayoutParams(params); //give the button the new param
                break;
                case(1):

                    Spec rowSpec1; //make spec for row number
                    Spec columnSpec1; //make spec for column number
                    rowSpec1= spec(0); //set row number
                    columnSpec1= spec(1); //set column number
                    params= new GridLayout.LayoutParams(rowSpec1, columnSpec1); //change the param location to the location of the array indice the button occupies
                    buttons[text].setLayoutParams(params); //give the button the new param
                    break;
                case(2):

                    Spec rowSpec2; //make spec for row number
                    Spec columnSpec2; //make spec for column number
                    rowSpec2= spec(0); //set row number
                    columnSpec2= spec(2); //set column number
                    params= new GridLayout.LayoutParams(rowSpec2, columnSpec2); //change the param location to the location of the array indice the button occupies
                    buttons[text].setLayoutParams(params); //give the button the new param
                    break;
                case(3):

                    Spec rowSpec3; //make spec for row number
                    Spec columnSpec3; //make spec for column number
                    rowSpec3= spec(0); //set row number
                    columnSpec3= spec(3); //set column number
                    params= new GridLayout.LayoutParams(rowSpec3, columnSpec3); //change the param location to the location of the array indice the button occupies
                    buttons[text].setLayoutParams(params); //give the button the new param
                    break;
                case(4):

                    Spec rowSpec4; //make spec for row number
                    Spec columnSpec4; //make spec for column number
                    rowSpec4= spec(1); //set row number
                    columnSpec4= spec(0); //set column number
                    params= new GridLayout.LayoutParams(rowSpec4, columnSpec4); //change the param location to the location of the array indice the button occupies
                    buttons[text].setLayoutParams(params); //give the button the new param
                    break;
                case(5):

                    Spec rowSpec5; //make spec for row number
                    Spec columnSpec5; //make spec for column number
                    rowSpec5= spec(1); //set row number
                    columnSpec5= spec(1); //set column number
                    params= new GridLayout.LayoutParams(rowSpec5, columnSpec5); //change the param location to the location of the array indice the button occupies
                    buttons[text].setLayoutParams(params); //give the button the new param
                    break;
                case(6):

                    Spec rowSpec6; //make spec for row number
                    Spec columnSpec6; //make spec for column number
                    rowSpec6= spec(1); //set row number
                    columnSpec6= spec(2); //set column number
                    params= new GridLayout.LayoutParams(rowSpec6, columnSpec6); //change the param location to the location of the array indice the button occupies
                    buttons[text].setLayoutParams(params); //give the button the new param
                    break;
                case(7):

                    Spec rowSpec7; //make spec for row number
                    Spec columnSpec7; //make spec for column number
                    rowSpec7= spec(1); //set row number
                    columnSpec7= spec(3); //set column number
                    params= new GridLayout.LayoutParams(rowSpec7, columnSpec7); //change the param location to the location of the array indice the button occupies
                    buttons[text].setLayoutParams(params); //give the button the new param
                    break;
                case(8):

                    Spec rowSpec8; //make spec for row number
                    Spec columnSpec8; //make spec for column number
                    rowSpec8= spec(2); //set row number
                    columnSpec8= spec(0); //set column number
                    params= new GridLayout.LayoutParams(rowSpec8, columnSpec8); //change the param location to the location of the array indice the button occupies
                    buttons[text].setLayoutParams(params); //give the button the new param
                    break;
                case(9):

                    Spec rowSpec9; //make spec for row number
                    Spec columnSpec9; //make spec for column number
                    rowSpec9= spec(2); //set row number
                    columnSpec9= spec(1); //set column number
                    params= new GridLayout.LayoutParams(rowSpec9, columnSpec9); //change the param location to the location of the array indice the button occupies
                    buttons[text].setLayoutParams(params); //give the button the new param
                    break;
                case(10):

                    Spec rowSpec10; //make spec for row number
                    Spec columnSpec10; //make spec for column number
                    rowSpec10= spec(2); //set row number
                    columnSpec10= spec(2); //set column number
                    params= new GridLayout.LayoutParams(rowSpec10, columnSpec10); //change the param location to the location of the array indice the button occupies
                    buttons[text].setLayoutParams(params); //give the button the new param
                    break;
                case(11):

                    Spec rowSpec11; //make spec for row number
                    Spec columnSpec11; //make spec for column number
                    rowSpec11= spec(2); //set row number
                    columnSpec11= spec(3); //set column number
                    params= new GridLayout.LayoutParams(rowSpec11, columnSpec11); //change the param location to the location of the array indice the button occupies
                    buttons[text].setLayoutParams(params); //give the button the new param
                    break;
                case(12):

                    Spec rowSpec12; //make spec for row number
                    Spec columnSpec12; //make spec for column number
                    rowSpec12= spec(3); //set row number
                    columnSpec12= spec(0); //set column number
                    params= new GridLayout.LayoutParams(rowSpec12, columnSpec12); //change the param location to the location of the array indice the button occupies
                    buttons[text].setLayoutParams(params); //give the button the new param
                    break;
                case(13):

                    Spec rowSpec13; //make spec for row number
                    Spec columnSpec13; //make spec for column number
                    rowSpec13= spec(3); //set row number
                    columnSpec13= spec(1); //set column number
                    params= new GridLayout.LayoutParams(rowSpec13, columnSpec13); //change the param location to the location of the array indice the button occupies
                    buttons[text].setLayoutParams(params); //give the button the new param
                    break;
                case(14):

                    Spec rowSpec14; //make spec for row number
                    Spec columnSpec14; //make spec for column number
                    rowSpec14= spec(3); //set row number
                    columnSpec14= spec(2); //set column number
                    params= new GridLayout.LayoutParams(rowSpec14, columnSpec14); //change the param location to the location of the array indice the button occupies
                    buttons[text].setLayoutParams(params); //give the button the new param
                    break;
                case(15):

                    Spec rowSpec15; //make spec for row number
                    Spec columnSpec15; //make spec for column number
                    rowSpec15= spec(3); //set row number
                    columnSpec15= spec(3); //set column number
                    params= new GridLayout.LayoutParams(rowSpec15, columnSpec15); //change the param location to the location of the array indice the button occupies
                    buttons[text].setLayoutParams(params); //give the button the new param
                    break;
            }


        }

    }


	public void slide(final Button button) { //check to see if touching a button will slide it or return invalid command
        inval =true;
		int button_num,button_position,empty_position;
		button_num=Integer.parseInt((String) button.getText());
     	button_position= find_position(button_num);
   		empty_position= find_position(0);
   		switch(empty_position)
   		{
   		case(0):
   			if(button_position==1||button_position==4) //possible locations of empty spot that would let this button (case number) move
   		    inval =false;
   		    break;
   		case(1):
   			if(button_position==0||button_position==2||button_position==5)
   		    inval =false;
   		    break;
   		case(2):
   			if(button_position==1||button_position==3||button_position==6)
   		    inval =false;
   		    break;
   		case(3):
   			if(button_position==2||button_position==7)
   		    inval =false;
   		    break;
   		case(4):
   			if(button_position==0||button_position==5||button_position==8)
   		    inval =false;
   		    break;
   		case(5):
   			if(button_position==1||button_position==4||button_position==6||button_position==9)
   		    inval =false;
   		    break;
   		case(6):
   			if(button_position==2||button_position==5||button_position==7||button_position==10)
   		    inval =false;
   		    break;
   		case(7):
   			if(button_position==3||button_position==6||button_position==11)
   		    inval =false;
   		    break;
   		case(8):
   			if(button_position==4||button_position==9||button_position==12)
   		    inval =false;
   		    break;
        case(9):
            if(button_position==5||button_position==8||button_position==10||button_position==13)
                inval =false;
            break;
        case(10):
            if(button_position==6||button_position==9||button_position==11||button_position==14)
                inval =false;
            break;
        case(11):
            if(button_position==7||button_position==10||button_position==15)
                inval =false;
            break;
        case(12):
            if(button_position==8||button_position==13)
                inval =false;
            break;
        case(13):
            if(button_position==9||button_position==12||button_position==14)
                inval =false;
            break;
        case(14):
            if(button_position==10||button_position==13||button_position==15)
                inval =false;
            break;
        case(15):
            if(button_position==11||button_position==14)
                inval =false;
            break;
   		}
   		
   		if(inval) //return positive text for valid moves or negative text for invalid move
   		{
   			command.setText("Can't move that");
   			return;
   		}
   		command.setText("Good move");
   		myList.remove(button_position);
   		myList.add(button_position, 0);
   		myList.remove(empty_position);
   		myList.add(empty_position, button_num);
   		
	
    	fill_grid(); //redraw grid for valid move
		moveCounter.setText(Integer.toString(Integer.parseInt((String) moveCounter.getText())+1)); //increment move counter

		 for(int i=0;i<16;i++) //checks to see if you have won yet
	        {
	           if(!Objects.equals(myList.get(i), end_state[i]))
	           {
                   return;
	           }
	        }
		 command.setText("You win!");
        timer.stop();
	}

}